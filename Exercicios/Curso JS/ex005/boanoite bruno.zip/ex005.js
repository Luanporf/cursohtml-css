var idade = 18
if (idade < 18) {
    console.log ('Você não é de maior')
} else {
    console.log ('Pode entrar, você é de maior!')
}